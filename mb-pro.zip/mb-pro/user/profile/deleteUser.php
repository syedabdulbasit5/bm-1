<?php
require_once('../../includes/dbh.inc.php');
require_once('../../includes/functions.inc.php');
userDeleteProfile($conn);
